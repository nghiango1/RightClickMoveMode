[← back to readme](README.md)

## 0.0.1
* Pre-release version.
* Using SMAPI 2.6
* Support right click for move, On/Off mod in game with hotkey "G"


## 1.0.3
* More bug fix